# 🔮 Oráculo Filosófico — Deploy en Railway

## Estructura del proyecto

```
oraculo-filosofico/
├── server.js          ← Servidor Express (backend + frontend)
├── package.json       ← Dependencias y script de inicio
├── public/
│   └── index.html     ← La web que ven los visitantes
└── README.md          ← Este archivo
```

Solo 3 archivos. Railway se encarga del resto.

---

## Paso a paso

### 1. Obtener tu API key de Anthropic

1. Ir a https://console.anthropic.com/
2. Crear cuenta (si no tenés)
3. Ir a "API Keys" → crear una nueva
4. Copiar la key (empieza con `sk-ant-...`)
5. Cargar crédito ($5 USD = ~1.500 consultas)

### 2. Subir a GitHub

Si ya tenés repos en GitHub:

1. Crear repositorio nuevo: `oraculo-filosofico`
2. Subir estos 3 archivos manteniendo la estructura:
   - `server.js` (en la raíz)
   - `package.json` (en la raíz)
   - `public/index.html` (dentro de carpeta `public`)
3. Commit y push

### 3. Deploy en Railway

1. Ir a tu dashboard de Railway (https://railway.app)
2. Click en "New Project"
3. Elegir "Deploy from GitHub repo"
4. Seleccionar `oraculo-filosofico`
5. Railway detecta automáticamente que es Node.js

### 4. Configurar la API key

En Railway, dentro de tu proyecto:
1. Click en el servicio desplegado
2. Ir a la pestaña "Variables"
3. Agregar:
   - `ANTHROPIC_API_KEY` = tu key de Anthropic (la que empieza con `sk-ant-...`)
4. Railway re-deploya automáticamente

### 5. Generar URL pública

1. Ir a la pestaña "Settings" de tu servicio
2. En la sección "Networking" → "Public Networking"
3. Click en "Generate Domain"
4. Railway te da una URL tipo: `oraculo-filosofico-production.up.railway.app`

¡Listo! Tu oráculo está online.

### 6. (Opcional) Dominio personalizado

Si querés `oraculo.meditacionesmodernas.com`:
1. En Settings → Networking → "Custom Domain"
2. Agregar: `oraculo.meditacionesmodernas.com`
3. Railway te da un registro CNAME
4. Ir al panel DNS de tu dominio y agregar ese CNAME
5. Esperar propagación (~5 min)

### 7. (Opcional) Activar modo Serverless

Para ahorrar costos cuando no hay visitas:
1. Settings → Deploy → Serverless
2. Activar "Enable Serverless"
3. El servicio se duerme tras 10 min sin tráfico
4. Se despierta solo cuando llega una visita (~2-3 seg)

---

## Costos

| Concepto | Costo |
|----------|-------|
| Railway Hobby | $5 USD/mes (incluye $5 de uso) |
| API Anthropic | ~$0.003 por consulta |
| 1.000 consultas/mes | ~$3 USD |
| 10.000 consultas/mes | ~$30 USD |

Con el modo Serverless activado, el consumo de Railway es mínimo.

---

## Modificaciones

- **Cambiar diseño:** editar `public/index.html`
- **Cambiar el prompt:** editar `server.js` (buscar `SYSTEM_PROMPT`)
- **Cambiar sugerencias:** editar `public/index.html` (buscar `sug-chip`)

Cada push a GitHub dispara re-deploy automático en Railway.
